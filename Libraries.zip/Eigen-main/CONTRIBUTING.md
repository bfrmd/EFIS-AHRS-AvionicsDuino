# Contributing
Please see Eigen's [contributing guide](http://eigen.tuxfamily.org/index.php?title=Contributing_to_Eigen).